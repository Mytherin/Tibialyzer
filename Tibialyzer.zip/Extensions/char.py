
import webbrowser

webbrowser.open('https://secure.tibia.com/community/?subtopic=characters&name=%s' % _parameter)